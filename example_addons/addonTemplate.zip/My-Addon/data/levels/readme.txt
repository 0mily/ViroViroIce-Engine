Put your levels JSON files here!

You can automatically generate a file if you use the Level Editor by pressing 7 in the main menu.

For more info, go here:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Adding-a-New-Week